# Etapa 1 — Prática: ciclo completo de delegação controlada

- **Pacote:** pg-d05 — pratica guiada U10/D6+D2 (delegacao controlada)
- **Publico:** learner
- **Arquivo:** `pg-d05-etapa-1-pratica.zip` (cumulativo: contem as etapas anteriores)

## Proposito

Entregar tudo o que o aprendiz-controlador usa na sessão de 25–40 min: contrato e plano aprovados ANTES do diff (passo 1), verificador mecânico de escopo e de evidência, fixture determinística (biblioteca/testes), as duas rodadas do produtor simulado (r1 fora do escopo com alegação parcialmente verdadeira; r2 reentrega correta), ALLOWLIST do mundo fechado e a rúbrica com perChecks. Extração única que roda os comandos do enunciado verbatim, offline (Python 3 + git local).

## Limite desta etapa

Não contém NENHUM arquivo de guia-de-correcao (solução, veredito-r1 modelo, recibo-exemplo e recibo-falso) nem o MANIFEST.md de proveniência do pacote — as âncoras de integridade que o enunciado consulta no MANIFEST.md (sha256 de insumos/fixture/testes.py etc.) estão no INVENTARIO.txt desta etapa, linha a linha.

## O que esta etapa adiciona (13 arquivos)

- `ALLOWLIST.md`
- `enunciado.md`
- `exemplo-trabalhado.md`
- `insumos/CONTRATO.md`
- `insumos/PLANO-APROVADO.md`
- `insumos/delegacao-r1/diff-r1.patch`
- `insumos/delegacao-r1/resposta-produtor-r1.md`
- `insumos/delegacao-r2/diff-r2.patch`
- `insumos/delegacao-r2/resposta-produtor-r2.md`
- `insumos/fixture/biblioteca.py`
- `insumos/fixture/testes.py`
- `insumos/verifica_delegacao.py`
- `rubrica-v1.md`

## Como comecar

1. Extraia este ZIP em uma pasta limpa (ele e cumulativo; extrair por
   cima da etapa anterior na mesma pasta tambem funciona).
2. Leia (ou releia) `enunciado.md` e siga a ordem dos passos: contrato
   e plano ANTES do diff do produtor.
3. Confira a integridade com `INVENTARIO.txt` (sha256 por arquivo); as
   ancoras que o enunciado busca no MANIFEST.md do pacote estao la.

## Disciplina declarada (nao barreira segura)

A ordem das etapas e disciplina declarada, nao enforcement
criptografico: o kit nao controla quando voce abre cada arquivo e nao
emite nota ou mastery. A separacao existe para proteger o metodo
(produtor != verificador: o gabarito so depois da tentativa). Dados
100% sinteticos; nenhuma eficacia real de agente/aluno e alegada.

## Proveniencia

- Fonte imutavel: PR #646 @ `f7e3228a80cecc68e426e7d59d080a234d249104` (repo dandpb/aidevschool), curriculum/sequencia-dev-guiada/pg-d05-delegacao-controlada/
- Construido por `packager.py` (AID-3668), stdlib apenas, ZIP deterministico.
- Inventario exato desta construcao: `INVENTARIO.txt` (13 arquivos do kit).
