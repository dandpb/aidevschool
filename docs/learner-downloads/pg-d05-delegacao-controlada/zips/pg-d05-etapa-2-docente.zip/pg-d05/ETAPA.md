# Etapa 2 — Docente: gabaritos e prova V&E (pós-tentativa)

- **Pacote:** pg-d05 — pratica guiada U10/D6+D2 (delegacao controlada)
- **Publico:** teacher
- **Arquivo:** `pg-d05-etapa-2-docente.zip` (cumulativo: contem as etapas anteriores)

## Proposito

Gabarito completo para uso docente ou autoavaliação APÓS a tentativa (enunciado §Limites: 'consulte após a tentativa'): solução com saídas reais de todos os comandos do aluno, veredito-r1 modelo com cláusulas e retrabalho, recibo-exemplo que passa no verificador e recibo-falso que reprova (o negativo anti-falsa-comprovação). Cumulativa sobre a Etapa 1: com as duas etapas extraídas na mesma pasta, 'python3 insumos/verifica_delegacao.py selftest' reproduz a prova V&E congelada do pacote (APROVADO 4/4).

## Limite desta etapa

Uso docente/avaliação pós-tentativa; não faz parte da tentativa do aprendiz. Contém exatamente os 4 arquivos de guia-de-correcao do pacote aceito — nenhum conteúdo reautorado.

## O que esta etapa adiciona (4 arquivos)

- `guia-de-correcao/exemplos/recibo-falso.md`
- `guia-de-correcao/recibo-exemplo/recibo-aceite-r2.md`
- `guia-de-correcao/solucao.md`
- `guia-de-correcao/veredito-r1.md`

Etapa anterior: Etapa 1 — Prática: ciclo completo de delegação controlada (pg-d05-etapa-1-pratica.zip).

## Como comecar

1. Extraia este ZIP em uma pasta limpa (ele e cumulativo; extrair por
   cima da etapa anterior na mesma pasta tambem funciona).
2. Leia (ou releia) `enunciado.md` e siga a ordem dos passos: contrato
   e plano ANTES do diff do produtor.
3. Confira a integridade com `INVENTARIO.txt` (sha256 por arquivo); as
   ancoras que o enunciado busca no MANIFEST.md do pacote estao la.

## Disciplina declarada (nao barreira segura)

A ordem das etapas e disciplina declarada, nao enforcement
criptografico: o kit nao controla quando voce abre cada arquivo e nao
emite nota ou mastery. A separacao existe para proteger o metodo
(produtor != verificador: o gabarito so depois da tentativa). Dados
100% sinteticos; nenhuma eficacia real de agente/aluno e alegada.

## Proveniencia

- Fonte imutavel: PR #646 @ `f7e3228a80cecc68e426e7d59d080a234d249104` (repo dandpb/aidevschool), curriculum/sequencia-dev-guiada/pg-d05-delegacao-controlada/
- Construido por `packager.py` (AID-3668), stdlib apenas, ZIP deterministico.
- Inventario exato desta construcao: `INVENTARIO.txt` (17 arquivos do kit).
