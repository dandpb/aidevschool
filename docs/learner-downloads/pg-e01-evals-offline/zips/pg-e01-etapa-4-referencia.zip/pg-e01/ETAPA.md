# Etapa 4 — Referência mínima (passo 7)

- **Pacote:** pg-e01 — pratica guiada U13/D5 (evals offline de saidas de modelo)
- **Publico:** learner
- **Arquivo:** `pg-e01-etapa-4-referencia.zip` (cumulativo: contem as etapas anteriores)

## Proposito

Conter exatamente o que o passo 7 do enunciado manda consultar depois da sua tentativa: guia-de-correcao/proposta-referencia.md, para comparar com a SUA proposta.

## Limite desta etapa

Contém apenas proposta-referencia.md. critérios-referencia, solucao.md e testes.py (Etapa 5) continuam fora. Alternativas fundamentadas que cumpram a rubrica valem met.

## O que esta etapa adiciona (1 arquivos)

- `guia-de-correcao/proposta-referencia.md`

Etapa anterior: Etapa 3 — Held-out: casos NOVOS (A vs B e B vs C) (pg-e01-etapa-3-heldout.zip).

## Como comecar

1. Extraia este ZIP em uma pasta limpa (ele e cumulativo; extrair por
   cima da etapa anterior na mesma pasta tambem funciona).
2. Leia (ou releia) `enunciado.md` e siga a ordem dos passos.
3. Confira a integridade com `INVENTARIO.txt` (sha256 por arquivo).

## Disciplina declarada (nao barreira segura)

A ordem das etapas e disciplina declarada, nao enforcement
criptografico: o kit nao controla quando voce abre cada arquivo e nao
emite nota ou mastery. A separacao existe para proteger o metodo
(criterios antes dos resultados; heldout apos a proposta). Dados 100%
sinteticos; nenhuma eficacia real de modelo/prompt e alegada.

## Proveniencia

- Fonte imutavel: PR #645 @ `b028652d7853cbd4efdf15035d9f9414aeb76094` (repo dandpb/aidevschool), curriculum/praticas-evals-offline/pg-e01-evals-offline/
- Construido por `packager.py` (AID-3667), stdlib apenas, ZIP deterministico.
- Inventario exato desta construcao: `INVENTARIO.txt` (23 arquivos do kit).
