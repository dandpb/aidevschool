# Etapa 5 — Docente: guia completo de correção

- **Pacote:** pg-e01 — pratica guiada U13/D5 (evals offline de saidas de modelo)
- **Publico:** teacher
- **Arquivo:** `pg-e01-etapa-5-docente.zip` (cumulativo: contem as etapas anteriores)

## Proposito

Gabaritos completos (critérios-referencia, solucao com as saídas reais do scorer) e os 9 checks determinísticos (testes.py) para uso docente ou autoavaliação APÓS concluir a prática.

## Limite desta etapa

Uso docente/avaliação; não faz parte da tentativa do aprendiz.

## O que esta etapa adiciona (3 arquivos)

- `guia-de-correcao/criterios-referencia.md`
- `guia-de-correcao/solucao.md`
- `guia-de-correcao/testes.py`

Etapa anterior: Etapa 4 — Referência mínima (passo 7) (pg-e01-etapa-4-referencia.zip).

## Como comecar

1. Extraia este ZIP em uma pasta limpa (ele e cumulativo; extrair por
   cima da etapa anterior na mesma pasta tambem funciona).
2. Leia (ou releia) `enunciado.md` e siga a ordem dos passos.
3. Confira a integridade com `INVENTARIO.txt` (sha256 por arquivo).

## Disciplina declarada (nao barreira segura)

A ordem das etapas e disciplina declarada, nao enforcement
criptografico: o kit nao controla quando voce abre cada arquivo e nao
emite nota ou mastery. A separacao existe para proteger o metodo
(criterios antes dos resultados; heldout apos a proposta). Dados 100%
sinteticos; nenhuma eficacia real de modelo/prompt e alegada.

## Proveniencia

- Fonte imutavel: PR #645 @ `b028652d7853cbd4efdf15035d9f9414aeb76094` (repo dandpb/aidevschool), curriculum/praticas-evals-offline/pg-e01-evals-offline/
- Construido por `packager.py` (AID-3667), stdlib apenas, ZIP deterministico.
- Inventario exato desta construcao: `INVENTARIO.txt` (26 arquivos do kit).
