# Etapa 3 — Held-out: casos NOVOS (A vs B e B vs C)

- **Pacote:** pg-e01 — pratica guiada U13/D5 (evals offline de saidas de modelo)
- **Publico:** heldout
- **Arquivo:** `pg-e01-etapa-3-heldout.zip` (cumulativo: contem as etapas anteriores)

## Proposito

Abrir o heldout SOMENTE após registrar sua proposta v2.1: testar se o diagnóstico se reproduz em casos novos (A vs B) e se a correção de referência C recupera a fatia sem derrubar as outras (B vs C) — enunciado, passo 6 da tentativa.

## Limite desta etapa

Sem guia-de-correcao (a proposta-referencia.md da Etapa 4 continua fora). A variante C é a correção de referência sintética do pacote, usada aqui por desenho do passo 6.

## O que esta etapa adiciona (4 arquivos)

- `insumos/fixture/heldout/casos_heldout.json`
- `insumos/fixture/heldout/saidas_A_heldout.json`
- `insumos/fixture/heldout/saidas_B_heldout.json`
- `insumos/fixture/heldout/saidas_C_heldout.json`

Etapa anterior: Etapa 2 — Tentativa: conjunto base (A vs B) (pg-e01-etapa-2-base.zip).

## Como comecar

1. Extraia este ZIP em uma pasta limpa (ele e cumulativo; extrair por
   cima da etapa anterior na mesma pasta tambem funciona).
2. Leia (ou releia) `enunciado.md` e siga a ordem dos passos.
3. Confira a integridade com `INVENTARIO.txt` (sha256 por arquivo).

## Disciplina declarada (nao barreira segura)

A ordem das etapas e disciplina declarada, nao enforcement
criptografico: o kit nao controla quando voce abre cada arquivo e nao
emite nota ou mastery. A separacao existe para proteger o metodo
(criterios antes dos resultados; heldout apos a proposta). Dados 100%
sinteticos; nenhuma eficacia real de modelo/prompt e alegada.

## Proveniencia

- Fonte imutavel: PR #645 @ `b028652d7853cbd4efdf15035d9f9414aeb76094` (repo dandpb/aidevschool), curriculum/praticas-evals-offline/pg-e01-evals-offline/
- Construido por `packager.py` (AID-3667), stdlib apenas, ZIP deterministico.
- Inventario exato desta construcao: `INVENTARIO.txt` (22 arquivos do kit).
