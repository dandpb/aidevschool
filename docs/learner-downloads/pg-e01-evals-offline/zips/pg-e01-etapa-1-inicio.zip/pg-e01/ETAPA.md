# Etapa 1 — Início: cenário, critérios e plano de medição

- **Pacote:** pg-e01 — pratica guiada U13/D5 (evals offline de saidas de modelo)
- **Publico:** learner
- **Arquivo:** `pg-e01-etapa-1-inicio.zip` (cumulativo: contem as etapas anteriores)

## Proposito

Entregar o cenário PrismaDesk, os prompts v1/v2, o modelo de critérios, os casos base (tickets + rótulos dourados), o scorer determinístico e o exemplo trabalhado TrilhaFit completo, para que você declare e congele seus critérios e o plano de medição ANTES de ver qualquer saída do PrismaDesk (enunciado, passos 1 e 2 da tentativa).

## Limite desta etapa

Não contém NENHUMA saída do PrismaDesk (insumos/fixture/saidas_*.json), nem o heldout, nem o guia-de-correcao. As únicas saídas presentes são as do exemplo trabalhado TrilhaFit (exemplo/), leitura obrigatória do passo 1.

## O que esta etapa adiciona (16 arquivos)

- `enunciado.md`
- `exemplo-trabalhado.md`
- `exemplo/casos_base.json`
- `exemplo/heldout/casos_heldout.json`
- `exemplo/heldout/saidas_A_heldout.json`
- `exemplo/heldout/saidas_B_heldout.json`
- `exemplo/heldout/saidas_C_heldout.json`
- `exemplo/saidas_A_base.json`
- `exemplo/saidas_B_base.json`
- `insumos/CENARIO.md`
- `insumos/fixture/casos_base.json`
- `insumos/fixture/metricas.py`
- `insumos/modelo-de-criterios.md`
- `insumos/prompts/prompt_v1.md`
- `insumos/prompts/prompt_v2.md`
- `rubrica-v1.md`

## Como comecar

1. Extraia este ZIP em uma pasta limpa (ele e cumulativo; extrair por
   cima da etapa anterior na mesma pasta tambem funciona).
2. Leia (ou releia) `enunciado.md` e siga a ordem dos passos.
3. Confira a integridade com `INVENTARIO.txt` (sha256 por arquivo).

## Disciplina declarada (nao barreira segura)

A ordem das etapas e disciplina declarada, nao enforcement
criptografico: o kit nao controla quando voce abre cada arquivo e nao
emite nota ou mastery. A separacao existe para proteger o metodo
(criterios antes dos resultados; heldout apos a proposta). Dados 100%
sinteticos; nenhuma eficacia real de modelo/prompt e alegada.

## Proveniencia

- Fonte imutavel: PR #645 @ `b028652d7853cbd4efdf15035d9f9414aeb76094` (repo dandpb/aidevschool), curriculum/praticas-evals-offline/pg-e01-evals-offline/
- Construido por `packager.py` (AID-3667), stdlib apenas, ZIP deterministico.
- Inventario exato desta construcao: `INVENTARIO.txt` (16 arquivos do kit).
