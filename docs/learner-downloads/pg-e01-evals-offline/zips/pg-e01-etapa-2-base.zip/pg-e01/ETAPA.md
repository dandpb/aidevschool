# Etapa 2 — Tentativa: conjunto base (A vs B)

- **Pacote:** pg-e01 — pratica guiada U13/D5 (evals offline de saidas de modelo)
- **Publico:** learner
- **Arquivo:** `pg-e01-etapa-2-base.zip` (cumulativo: contem as etapas anteriores)

## Proposito

Liberar as saídas A e B do conjunto base para você rodar o scorer, registrar o veredito real, diagnosticar a fatia que piorou e escrever a proposta v2.1 com hash (enunciado, passos 3 a 5 da tentativa).

## Limite desta etapa

Sem heldout, sem variante C, sem guia-de-correcao. Extraia por cima da Etapa 1 (mesma pasta).

## O que esta etapa adiciona (2 arquivos)

- `insumos/fixture/saidas_A_base.json`
- `insumos/fixture/saidas_B_base.json`

Etapa anterior: Etapa 1 — Início: cenário, critérios e plano de medição (pg-e01-etapa-1-inicio.zip).

## Como comecar

1. Extraia este ZIP em uma pasta limpa (ele e cumulativo; extrair por
   cima da etapa anterior na mesma pasta tambem funciona).
2. Leia (ou releia) `enunciado.md` e siga a ordem dos passos.
3. Confira a integridade com `INVENTARIO.txt` (sha256 por arquivo).

## Disciplina declarada (nao barreira segura)

A ordem das etapas e disciplina declarada, nao enforcement
criptografico: o kit nao controla quando voce abre cada arquivo e nao
emite nota ou mastery. A separacao existe para proteger o metodo
(criterios antes dos resultados; heldout apos a proposta). Dados 100%
sinteticos; nenhuma eficacia real de modelo/prompt e alegada.

## Proveniencia

- Fonte imutavel: PR #645 @ `b028652d7853cbd4efdf15035d9f9414aeb76094` (repo dandpb/aidevschool), curriculum/praticas-evals-offline/pg-e01-evals-offline/
- Construido por `packager.py` (AID-3667), stdlib apenas, ZIP deterministico.
- Inventario exato desta construcao: `INVENTARIO.txt` (18 arquivos do kit).
